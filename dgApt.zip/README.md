## Available Scripts

In the project directory, you can run :
1. `npm install`
2. `npm start`