import React, { Component } from 'react';
import { saveTitle, saveSubtitle, addQuestion } from '../actions/fromAction';
import { connect } from 'react-redux'
import Card from './card';
import {
  ThemeProvider,
  getMuiTheme,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid
} from '@material-ui/core';
import theme from '../theme/theme';


class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      question: '',
      questionType: '',
      addQuestionOption: [],
      answers: ''
    }
  }


  addOptionsQuestions = () => {
    this.setState({
      addQuestionOption: [...this.state.addQuestionOption, this.state.answers]
    })
    this.setState({
      answers: ''
    })
  }
  handleQuestion = name => event => {
    this.setState({
      question: event.target.value
    })
  }

  handleAnswers = name => event => {
    this.setState({
      answers: event.target.value
    })
  }

  handleQuestionType = event => {
    this.setState({
      questionType: event.target.value
    })
  };
  addQuestions = () => {
    const { question, answers, questionType, addQuestionOption } = this.state;
    this.props.addQuestion(
      {
        question,
        answers,
        questionType,
        options: addQuestionOption
      }
    )
    this.setState({
      question: '', answers: '', addQuestionOption: ''
    })
  };


  handleChange = name => event => {
    if (name === 'title') {
      this.props.saveTitle(event.target.value)
    }
    else {
      this.props.saveSubtitle(event.target.value)
    }
  };
  renderQuestions = () => {
    return <Grid container >
      {this.props.questions.map((questionObj) =>
        <Grid container >
          <Grid item xs={12} style={{textAlign:'start'}}>
            <span style={{color:'red'}}>{ `Q ) ${questionObj.question}`}</span>
          </Grid>
          {questionObj.questionType === "Short" && <Grid item xs={12} style={{textAlign:'start'}}>
           <span style={{color:'blue'}}> {questionObj.answers}</span>
          </Grid>
          }
          {
            questionObj.questionType === "Multiple" && questionObj.options.map((optionObj) => <Grid item xs={3}><span style={{color:'blue'}}> <input type="radio" />{optionObj}</span></Grid>)
          }
          {
            questionObj.questionType === "Check" && questionObj.options.map((optionObj) => <Grid item xs={3}><span style={{color:'blue'}}> <input type="checkbox" checked=""/>{optionObj}</span></Grid>)
          }
        </Grid>
      )}
    </Grid>
  }
  render() {
    return (
      <ThemeProvider theme={theme}>
        <div style={{ textAlign: 'center' }}>
          <Grid container >
            <Grid item={true} xs={6} style={{ display: 'flex', justifyContent: 'center' }}>
              <Card>
                <Grid container >
                  <Grid item xs={12} style={{ textAlign: 'center' }}>
                    <TextField
                      id="standard-name"
                      label="Form Title"
                      // className={classes.textField}
                      // value={}
                      onChange={this.handleChange('title')}
                      margin="normal"
                    />
                  </Grid>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                  <TextField
                    id="standard-name"
                    label="Form Sub Title"
                    // className={classes.textField}
                    // value={}
                    onChange={this.handleChange('subTitle')}
                    margin="normal"
                  />
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                  <Button variant="contained">Default</Button>
                </Grid>
              </Card>
            </Grid>
            <Grid item={true} xs={6} style={{ display: 'flex', justifyContent: 'center' }} >
              <Card>
                <Grid container >
                  <Grid item xs={9} style={{ textAlign: 'center' }}>
                    <TextField
                      label="Question"
                      value={this.state.question}
                      onChange={this.handleQuestion('question')}
                      margin="normal"
                    />
                  </Grid>
                  <Grid item xs={3}>
                    <FormControl variant="outlined" style={{ width: '100%' }}>
                      <InputLabel >Question Type</InputLabel>
                      <Select
                        onChange={this.handleQuestionType}
                        label="Select Question Type"
                        value={'Short'}
                      >
                        <MenuItem value={'Short'}>Short</MenuItem>
                        <MenuItem value={'Multiple'}>Multiple</MenuItem>
                        <MenuItem value={'Check'}>Check</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} style={{ textAlign: 'center' }}>
                    <TextField
                      label="Answer"
                      value={this.state.answers}
                      onChange={this.handleAnswers('subTitle')}
                      margin="normal"
                    />
                  </Grid>
                  <Grid item xs={12} style={{ textAlign: 'center' }}>
                    {this.state.questionType === 'Multiple' || this.state.questionType === 'Check'  && <Button variant="contained" onClick={this.addOptionsQuestions}>Add Question Options</Button>}
                    <Button variant="contained" onClick={this.addQuestions}>Add Question</Button>
                  </Grid>
                </Grid>
              </Card>
            </Grid>


            <Grid item={true} xs={12} style={{ display: 'flex', justifyContent: 'center' }}>
              {this.props.formTitleData.title && <Card>
                <h2 style={{textAlign:'start',margin:'0'}}>{this.props.formTitleData.title}</h2>
                <h4 style={{textAlign:'start',margin:'0'}}>{this.props.formTitleData.subTitle}</h4>
                {this.props.questions.length ? <h5 style={{textAlign:'start',margin:'10px 0px'}}>Questions</h5> : ''}
                {this.props.questions.length ? <hr /> : ''}
                {
                  this.renderQuestions()
                }
              </Card>
              }
            </Grid>
          </Grid>
        </div>
      </ThemeProvider >
    );
  }
}

function mapStateToProps({ FromReducer }) {
  return {
    formTitleData: FromReducer.formTitleData,
    questions: FromReducer.questionsModal,
  }
}
export default connect(
  mapStateToProps,
  { saveTitle, saveSubtitle, addQuestion }
)(App)