export function saveTitle(value) {
    return {
        type: 'SAVE_TITLE_FORM',
        payload: value
    }
}

export function saveSubtitle(value) {
    console.log(value)
    return {
        type: 'SAVE_SUB_TITLE_FORM',
        payload: value
    }
}

export function addQuestion(value) {
    return {
        type: 'SAVE_QUESTION',
        payload: value
    }
}