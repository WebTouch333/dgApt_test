import { combineReducers } from 'redux';
import FromReducer from './app_reducer';
const rootReducer = combineReducers({
    FromReducer:FromReducer
})

export default rootReducer