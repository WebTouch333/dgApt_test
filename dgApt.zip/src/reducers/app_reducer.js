
const INITIAL_STATE = {
    formTitleData: {
        title: '',
        subTitle: ''
    },
    questionsModal: [

    ]
}

export default function (state = INITIAL_STATE, action) {
    switch (action.type) {
        case 'SAVE_TITLE_FORM':
            return {
                ...state,
                formTitleData: {
                    ...state.formTitleData,
                    title: action.payload,
                }
            }
        case 'SAVE_SUB_TITLE_FORM':
            return {
                ...state,
                formTitleData: {
                    ...state.formTitleData,
                    subTitle: action.payload,
                }
            }
        case 'SAVE_QUESTION':
            return {
                ...state,
                questionsModal: [
                    ...state.questionsModal,
                    action.payload
                ]
            }
        default:
            return state
    }
    return state
}